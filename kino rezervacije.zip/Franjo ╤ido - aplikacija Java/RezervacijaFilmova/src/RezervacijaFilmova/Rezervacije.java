/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package RezervacijaFilmova;

import java.beans.PropertyChangeListener;
import java.beans.PropertyChangeSupport;
import java.io.Serializable;
import java.util.Date;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.persistence.Transient;

/**
 *
 * @author franjo
 */
@Entity
@Table(name = "rezervacije", catalog = "rezervacijafilmova", schema = "")
@NamedQueries({
    @NamedQuery(name = "Rezervacije.findAll", query = "SELECT r FROM Rezervacije r")
    , @NamedQuery(name = "Rezervacije.findById", query = "SELECT r FROM Rezervacije r WHERE r.id = :id")
    , @NamedQuery(name = "Rezervacije.findByImeRezervacije", query = "SELECT r FROM Rezervacije r WHERE r.imeRezervacije = :imeRezervacije")
    , @NamedQuery(name = "Rezervacije.findBySjedala", query = "SELECT r FROM Rezervacije r WHERE r.sjedala = :sjedala")
    , @NamedQuery(name = "Rezervacije.findByDatum", query = "SELECT r FROM Rezervacije r WHERE r.datum = :datum")
    , @NamedQuery(name = "Rezervacije.findByKontaktBroj", query = "SELECT r FROM Rezervacije r WHERE r.kontaktBroj = :kontaktBroj")
, @NamedQuery(name = "Rezervacije.findBynazivFilma", query = "SELECT r FROM Rezervacije r WHERE r.nazivFilma = :nazivFilma")})
public class Rezervacije implements Serializable {

    @Transient
    private PropertyChangeSupport changeSupport = new PropertyChangeSupport(this);

    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "ID")
    private Integer id;
    @Basic(optional = false)
    @Column(name = "ImeRezervacije")
    private String imeRezervacije;
    @Basic(optional = false)
    @Column(name = "Sjedala")
    private int sjedala;
    @Basic(optional = false)
    @Column(name = "Datum")
    @Temporal(TemporalType.DATE)
    private Date datum;
    @Basic(optional = false)
    @Column(name = "KontaktBroj")
    private String kontaktBroj;
    @Basic(optional = false)
    @Column(name = "nazivFilma")
    private String nazivFilma;

    public Rezervacije() {
    }

    public Rezervacije(Integer id) {
        this.id = id;
    }

    public Rezervacije(Integer id, String imeRezervacije, int sjedala, Date datum, String kontaktBroj, String nazivFilma) {
        this.id = id;
        this.imeRezervacije = imeRezervacije;
        this.sjedala = sjedala;
        this.datum = datum;
        this.kontaktBroj = kontaktBroj;
        this.nazivFilma = nazivFilma;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        Integer oldId = this.id;
        this.id = id;
        changeSupport.firePropertyChange("id", oldId, id);
    }

    public String getImeRezervacije() {
        return imeRezervacije;
    }

    public void setImeRezervacije(String imeRezervacije) {
        String oldImeRezervacije = this.imeRezervacije;
        this.imeRezervacije = imeRezervacije;
        changeSupport.firePropertyChange("imeRezervacije", oldImeRezervacije, imeRezervacije);
    }

    public int getSjedala() {
        return sjedala;
    }

    public void setSjedala(int sjedala) {
        int oldSjedala = this.sjedala;
        this.sjedala = sjedala;
        changeSupport.firePropertyChange("sjedala", oldSjedala, sjedala);
    }

    public Date getDatum() {
        return datum;
    }

    public void setDatum(Date datum) {
        Date oldDatum = this.datum;
        this.datum = datum;
        changeSupport.firePropertyChange("datum", oldDatum, datum);
    }

    public String getKontaktBroj() {
        return kontaktBroj;
    }

    public void setKontaktBroj(String kontaktBroj) {
        String oldKontaktBroj = this.kontaktBroj;
        this.kontaktBroj = kontaktBroj;
        changeSupport.firePropertyChange("kontaktBroj", oldKontaktBroj, kontaktBroj);
    }
    
    public String getNazivFilma() {
        return nazivFilma;
    }

    public void setNazivFilma(String nazivFilma){
        String oldNaziv = this.nazivFilma;
        this.nazivFilma = nazivFilma;
        changeSupport.firePropertyChange("nazivFilma", oldNaziv, nazivFilma);
    }
    
    @Override
    public int hashCode() {
        int hash = 0;
        hash += (id != null ? id.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Rezervacije)) {
            return false;
        }
        Rezervacije other = (Rezervacije) object;
        if ((this.id == null && other.id != null) || (this.id != null && !this.id.equals(other.id))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "rezervacijafilmova.Rezervacije[ id=" + id + " ]";
    }

    public void addPropertyChangeListener(PropertyChangeListener listener) {
        changeSupport.addPropertyChangeListener(listener);
    }

    public void removePropertyChangeListener(PropertyChangeListener listener) {
        changeSupport.removePropertyChangeListener(listener);
    }
    
}
