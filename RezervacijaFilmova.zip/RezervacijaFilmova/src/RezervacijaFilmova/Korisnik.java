/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package RezervacijaFilmova;

import static java.lang.Class.forName;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.Date;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;

/**
 *
 * @author franjo
 */
public class Korisnik {
    
    String ime;
    String prezime;
    String uloga;
    String email;
    String lozinka;
    String username;
    int brojtelefona;


    public Korisnik(String username, String ime, String prezime, String uloga, String email, String lozinka, int brojtelefona) {
        this.ime = ime;
        this.prezime = prezime;
        this.uloga = uloga;
        this.email = email;
        this.lozinka = lozinka;
        this.brojtelefona = brojtelefona;
        this.username = username;
    }

    public Korisnik() {
    }

    public String getIme() {
        return ime;
    }

    public void setIme(String ime) {
        this.ime = ime;
    }

    public String getPrezime() {
        return prezime;
    }

    public void setPrezime(String prezime) {
        this.prezime = prezime;
    }

    public String getUloga() {
        return uloga;
    }

    public void setUloga(String uloga) {
        this.uloga = uloga;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getLozinka() {
        return lozinka;
    }

    public void setLozinka(String lozinka) {
        this.lozinka = lozinka;
    }

    public int getBrojtelefona() {
        return brojtelefona;
    }

    public void setBrojtelefona(int brojtelefona) {
        this.brojtelefona = brojtelefona;
    }
    
    public void infoMessage(String message,String title)
    {
        JOptionPane.showMessageDialog(null, message, title, JOptionPane.INFORMATION_MESSAGE);
    }
    
    public boolean  logirajSe(String kime, String klozinka)
    {
        try{
               Class.forName("com.mysql.jdbc.Driver");
               String databaseURL="jdbc:mysql://localhost:3306/rezervacijafilmova";
               Connection con=DriverManager.getConnection(databaseURL, "root","");
               Statement stat = con.createStatement();
               String selectQuery = "select * from korisnik where username ='"+kime+"' and Lozinka='"+klozinka+"'";
               ResultSet rs = stat.executeQuery(selectQuery);
               if(rs.next()==true){
                   infoMessage("Dobrodošli admine" , "Info");
                   return true;
               }
               else{
                   infoMessage("Nema admina sa tim podatcima","Upozorenje");
                   return false;
               }
           }catch(Exception e)
           {
               infoMessage("Greška sa bazom","Upozorenje");
               return false;
           }
    }
 
    
    public void registrirajZaposlenika()
    {
        try{
                  
               Class.forName("com.mysql.jdbc.Driver");
               String databaseURL="jdbc:mysql://localhost:3306/rezervacijafilmova";
               Connection con=DriverManager.getConnection(databaseURL, "root","");
               Statement stat = con.createStatement();
                  
               String selectQuery = "select * from korisnik where username ='"+this.username+"'";
               ResultSet rs = stat.executeQuery(selectQuery);
                if(rs.next()){
                   
                   infoMessage("Već postoji taj korisnik!" , "UPOZORENJE");
                   
                     }
                else
                {
               String insertQuery = "insert into korisnik values (null,'"+this.username+"','"+this.ime+"','"+this.prezime+"',null,'"+this.email+"','"+this.brojtelefona+"','"+this.lozinka+"')";
               stat.executeUpdate(insertQuery);
               infoMessage("Korisnik uspješno dodan!" , "Info");        
                } 
           }catch(Exception e)
           {
                System.out.println(e);
               infoMessage("Greška sa bazom","Upozorenje");
             
           }
    }
    public void obrisiZaposlenika(String username)
    {
         try{
            Class.forName("com.mysql.jdbc.Driver");
            String databaseURL="jdbc:mysql://localhost:3306/rezervacijafilmova";
            Connection con=DriverManager.getConnection(databaseURL, "root","");
            Statement stat = con.createStatement();

            String selectQuery = "select * from korisnik where username  ='"+username+"'";
            ResultSet rs = stat.executeQuery(selectQuery);
            if(rs.next()){

                String deleteQuery = "delete from korisnik where username='"+username+"'";
                stat.executeUpdate(deleteQuery);
                infoMessage("Korisnik uspješno obrisan!" , "Info");;
            }
            else
            {
                infoMessage("Taj korisnik više ne postoji!", "Info");
            }

        }catch(Exception e)
        {
            System.out.println(e);
            infoMessage("Greška sa bazom","Upozorenje");

        }
    }
    public void obrisiRezervaciju(String rezervacija)
    {
        try{
               Class.forName("com.mysql.jdbc.Driver");
               String databaseURL="jdbc:mysql://localhost:3306/rezervacijafilmova";
               Connection con=DriverManager.getConnection(databaseURL, "root","");
               Statement stat = con.createStatement();
               
               String selectQuery = "select * from rezervacije where ID  ='"+rezervacija+"'";
               ResultSet rs = stat.executeQuery(selectQuery);
                if(rs.next()){
                   
                   
                   String deleteQuery = "delete from rezervacije where ID='"+rezervacija+"'";
                     stat.executeUpdate(deleteQuery);
                        infoMessage("Rezervacija uspješno obrisana!" , "Info");      
               }
                else
                {
                    infoMessage("Ta rezervacija više ne postoji!", "Info");
                }
               
                     
              
              
           }catch(Exception e)
           {
               System.out.println(e);
               infoMessage("Greška sa bazom","Upozorenje");
             
           }
        
    }
    public void dodajDatum(String datum)
    {
         try{
               Class.forName("com.mysql.jdbc.Driver");
               String databaseURL="jdbc:mysql://localhost:3306/rezervacijafilmova";
               Connection con=DriverManager.getConnection(databaseURL, "root","");
               Statement stat = con.createStatement();
               
               String selectQuery = "select * from datum where datum ='"+datum+"'";
               ResultSet rs = stat.executeQuery(selectQuery);
                if(rs.next()){
                   
                   infoMessage("Već postoji taj datum!" , "UPOZORENJE");
                   
               }
                else
                {
                     String insertQuery = "insert into datum values (null,'"+datum+"')";
                     stat.executeUpdate(insertQuery);
                        infoMessage("Datum uspješno dodan!" , "Info");
                }
              
              
           }catch(Exception e)
           {
                System.out.println(e);
               infoMessage("Greška sa bazom","Upozorenje");
             
           }
    }
     public void obrisiDatum(String datum)
    {
        try{
               Class.forName("com.mysql.jdbc.Driver");
               String databaseURL="jdbc:mysql://localhost:3306/rezervacijafilmova";
               Connection con=DriverManager.getConnection(databaseURL, "root","");
               Statement stat = con.createStatement();
               
               String selectQuery = "select * from datum where Datum  ='"+datum+"'";
               ResultSet rs = stat.executeQuery(selectQuery);
                if(rs.next()){
                   
                   
                   String deleteQuery = "delete from datum where Datum='"+datum+"'";
                     stat.executeUpdate(deleteQuery);
                        infoMessage("Datum uspješno obrisan!" , "Info");      
               }
                else
                {
                    infoMessage("Taj datum više ne postoji!", "Info");
                }
               
                     
              
              
           }catch(Exception e)
           {
               System.out.println(e);
               infoMessage("Greška sa bazom","Upozorenje");
             
           }
        
    }
     public void dodajFilm(String nazivFilma, String zanr, int godina)
    {
         try{
               Class.forName("com.mysql.jdbc.Driver");
               String databaseURL="jdbc:mysql://localhost:3306/rezervacijafilmova";
               Connection con=DriverManager.getConnection(databaseURL, "root","");
               Statement stat = con.createStatement();
               
               String selectQuery = "select * from film where nazivFilma ='"+nazivFilma+"'";
               ResultSet rs = stat.executeQuery(selectQuery);
                if(rs.next()){
                   
                   infoMessage("Već postoji taj film!" , "UPOZORENJE");
                   
               }
                else
                {
                     String insertQuery = "insert into film values (null,'"+nazivFilma+"','"+zanr+"','"+godina+"')";
                     stat.executeUpdate(insertQuery);
                        infoMessage("Film uspješno dodan!" , "Info");
                }
              
              
           }catch(Exception e)
           {
                System.out.println(e);
               infoMessage("Greška sa bazom","Upozorenje");
             
           }
    }
     public void obrisiFilm(String nazivFilma)
    {
        try{
               Class.forName("com.mysql.jdbc.Driver");
               String databaseURL="jdbc:mysql://localhost:3306/rezervacijafilmova";
               Connection con=DriverManager.getConnection(databaseURL, "root","");
               Statement stat = con.createStatement();
               
               String selectQuery = "select * from film where nazivFilma  ='"+nazivFilma+"'";
               ResultSet rs = stat.executeQuery(selectQuery);
                if(rs.next()){
                   
                   
                   String deleteQuery = "delete from film where nazivFilma='"+nazivFilma+"'";
                     stat.executeUpdate(deleteQuery);
                        infoMessage("Fil, uspješno obrisan!" , "Info");      
               }
                else
                {
                    infoMessage("Taj film više ne postoji!", "Info");
                }
               
                     
              
              
           }catch(Exception e)
           {
               System.out.println(e);
               infoMessage("Greška sa bazom","Upozorenje");
             
           }
        
    }
}
