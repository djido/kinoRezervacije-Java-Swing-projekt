/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package RezervacijaFilmova;

import java.beans.PropertyChangeListener;
import java.beans.PropertyChangeSupport;
import java.io.Serializable;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Transient;

/**
 *
 * @author m-pc
 */
@Entity
@Table(name = "film", catalog = "rezervacijafilmova", schema = "")
@NamedQueries({
    @NamedQuery(name = "Film.findAll", query = "SELECT f FROM Film f")
    , @NamedQuery(name = "Film.findById", query = "SELECT f FROM Film f WHERE f.id = :id")
    , @NamedQuery(name = "Film.findBynazivFilma", query = "SELECT f FROM Film f WHERE f.nazivFilma = :nazivFilma")
    , @NamedQuery(name = "Film.findByzanr", query = "SELECT f FROM Film f WHERE f.zanr = :zanr")
    , @NamedQuery(name = "Film.findBygodina", query = "SELECT f FROM Film f WHERE f.godina = :godina")})
public class Film implements Serializable {

    @Transient
    private PropertyChangeSupport changeSupport = new PropertyChangeSupport(this);

    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "ID")
    private Integer id;
    @Basic(optional = false)
    @Column(name = "nazivFilma")
    private String nazivFilma;
    @Basic(optional = false)
    @Column(name = "zanr")
    private String zanr;
    @Basic(optional = false)
    @Column(name = "godina")
    private int godina;
    
    public Film() {
    }

    public Film(Integer id) {
        this.id = id;
    }

    public Film(int id, String nazivFilma, String zanr, int godina) {
        this.id = id;
        this.nazivFilma = nazivFilma;
        this.zanr = zanr;
        this.godina = godina;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }
    
    public String getFilm() {
        return nazivFilma;
    }

    public void setFilm(String nazivFilma) {
        String oldNazivFilma = this.nazivFilma;
        this.nazivFilma = nazivFilma;
        changeSupport.firePropertyChange("nazivFilma", oldNazivFilma, nazivFilma);
    }
    
    public String getZanr() {
        return zanr;
    }

    public void setZanr(String zanr) {
        String oldZanr = this.zanr;
        this.zanr = zanr;
        changeSupport.firePropertyChange("zanr", oldZanr, zanr);
    }
    
    public int getGodina() {
        return godina;
    }

    public void setGodina(int godina) {
        int oldGodina = this.godina;
        this.godina = godina;
        changeSupport.firePropertyChange("godina", oldGodina, godina);
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (id != null ? id.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Film)) {
            return false;
        }
        Film other = (Film) object;
        if ((this.id == null && other.id != null) || (this.id != null && !this.id.equals(other.id))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "rezervacijafilmova.Film[ id=" + id + " ]";
    }
    public void addPropertyChangeListener(PropertyChangeListener listener) {
        changeSupport.addPropertyChangeListener(listener);
    }

    public void removePropertyChangeListener(PropertyChangeListener listener) {
        changeSupport.removePropertyChangeListener(listener);
    }
}
