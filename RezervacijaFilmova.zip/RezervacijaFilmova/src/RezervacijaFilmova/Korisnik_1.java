/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package RezervacijaFilmova;

import java.beans.PropertyChangeListener;
import java.beans.PropertyChangeSupport;
import java.io.Serializable;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Transient;

/**
 *
 * @author franjo
 */
@Entity
@Table(name = "korisnik", catalog = "rezervacijafilmova", schema = "")
@NamedQueries({
    @NamedQuery(name = "Korisnik_1.findAll", query = "SELECT k FROM Korisnik_1 k")
    , @NamedQuery(name = "Korisnik_1.findById", query = "SELECT k FROM Korisnik_1 k WHERE k.id = :id")
    , @NamedQuery(name = "Korisnik_1.findByUsername", query = "SELECT k FROM Korisnik_1 k WHERE k.username = :username")
    , @NamedQuery(name = "Korisnik_1.findByIme", query = "SELECT k FROM Korisnik_1 k WHERE k.ime = :ime")
    , @NamedQuery(name = "Korisnik_1.findByPrezime", query = "SELECT k FROM Korisnik_1 k WHERE k.prezime = :prezime")
    , @NamedQuery(name = "Korisnik_1.findByEmail", query = "SELECT k FROM Korisnik_1 k WHERE k.email = :email")
    , @NamedQuery(name = "Korisnik_1.findByUloga", query = "SELECT k FROM Korisnik_1 k WHERE k.uloga = :uloga")
    , @NamedQuery(name = "Korisnik_1.findByBrojTelefona", query = "SELECT k FROM Korisnik_1 k WHERE k.brojTelefona = :brojTelefona")
    , @NamedQuery(name = "Korisnik_1.findByLozinka", query = "SELECT k FROM Korisnik_1 k WHERE k.lozinka = :lozinka")})
public class Korisnik_1 implements Serializable {

    @Transient
    private PropertyChangeSupport changeSupport = new PropertyChangeSupport(this);

    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "ID")
    private Integer id;
    @Basic(optional = false)
    @Column(name = "username")
    private String username;
    @Basic(optional = false)
    @Column(name = "Ime")
    private String ime;
    @Basic(optional = false)
    @Column(name = "Prezime")
    private String prezime;
    @Basic(optional = false)
    @Column(name = "Email")
    private String email;
    @Basic(optional = false)
    @Column(name = "Uloga")
    private String uloga;
    @Basic(optional = false)
    @Column(name = "BrojTelefona")
    private int brojTelefona;
    @Basic(optional = false)
    @Column(name = "Lozinka")
    private String lozinka;

    public Korisnik_1() {
    }

    public Korisnik_1(Integer id) {
        this.id = id;
    }

    public Korisnik_1(Integer id, String username, String ime, String prezime, String email, String uloga, int brojTelefona, String lozinka) {
        this.id = id;
        this.username = username;
        this.ime = ime;
        this.prezime = prezime;
        this.email = email;
        this.uloga = uloga;
        this.brojTelefona = brojTelefona;
        this.lozinka = lozinka;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        Integer oldId = this.id;
        this.id = id;
        changeSupport.firePropertyChange("id", oldId, id);
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        String oldUsername = this.username;
        this.username = username;
        changeSupport.firePropertyChange("username", oldUsername, username);
    }

    public String getIme() {
        return ime;
    }

    public void setIme(String ime) {
        String oldIme = this.ime;
        this.ime = ime;
        changeSupport.firePropertyChange("ime", oldIme, ime);
    }

    public String getPrezime() {
        return prezime;
    }

    public void setPrezime(String prezime) {
        String oldPrezime = this.prezime;
        this.prezime = prezime;
        changeSupport.firePropertyChange("prezime", oldPrezime, prezime);
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        String oldEmail = this.email;
        this.email = email;
        changeSupport.firePropertyChange("email", oldEmail, email);
    }

    public String getUloga() {
        return uloga;
    }

    public void setUloga(String uloga) {
        String oldUloga = this.uloga;
        this.uloga = uloga;
        changeSupport.firePropertyChange("uloga", oldUloga, uloga);
    }

    public int getBrojTelefona() {
        return brojTelefona;
    }

    public void setBrojTelefona(int brojTelefona) {
        int oldBrojTelefona = this.brojTelefona;
        this.brojTelefona = brojTelefona;
        changeSupport.firePropertyChange("brojTelefona", oldBrojTelefona, brojTelefona);
    }

    public String getLozinka() {
        return lozinka;
    }

    public void setLozinka(String lozinka) {
        String oldLozinka = this.lozinka;
        this.lozinka = lozinka;
        changeSupport.firePropertyChange("lozinka", oldLozinka, lozinka);
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (id != null ? id.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Korisnik_1)) {
            return false;
        }
        Korisnik_1 other = (Korisnik_1) object;
        if ((this.id == null && other.id != null) || (this.id != null && !this.id.equals(other.id))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "rezervacijafilmova.Korisnik_1[ id=" + id + " ]";
    }

    public void addPropertyChangeListener(PropertyChangeListener listener) {
        changeSupport.addPropertyChangeListener(listener);
    }

    public void removePropertyChangeListener(PropertyChangeListener listener) {
        changeSupport.removePropertyChangeListener(listener);
    }
    
}
